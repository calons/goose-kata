package it.goosegame;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import it.goosegame.board.GameBoard;
import it.goosegame.board.cell.Cell;
import it.goosegame.board.cell.GooseCell;
import it.goosegame.board.command.AddCommand;
import it.goosegame.board.command.Command;
import it.goosegame.board.command.CommandReader;
import it.goosegame.board.exception.DiceException;
import it.goosegame.board.exception.GameBoardException;
import it.goosegame.board.exception.MoveCommandExceptionException;
import it.goosegame.board.player.Player;
import it.goosegame.utility.Dice;

public class Game {

	private GameBoard gameboard;
	private List<Player> playerList= new ArrayList<Player>();


	public void run(){
		this.init();	

		boolean execution = true;
		Scanner scanner = new Scanner(System.in);
		while (execution) {


			String[] command = CommandReader.readCommand(scanner);

			switch (command[0].toLowerCase()) {
			case "add":

				Command c = new AddCommand();



				try {

					c.run(command,this.gameboard, this.playerList);
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				break;
			case "start":
				if (this.playerList.size()!=2){
					System.out.println("Players must be two! Please insert the player");
					break;
				}
				try {
					this.addUserToStartCell();
					execution = this.runGame();

				} catch (GameBoardException e) {
					System.out.println(e.getMessage());
				}
				break;
			case "move":
				System.out.println("Before use 'add player' and 'start' command");
				break;
			default:
				System.out.println("No command recognized");
				break;
			}
		}
		System.out.println("Game Completed");
		scanner.close();
	}



	private boolean runGame() {
		System.out.println("Start Game");
		Player playerTurn=null;
		Scanner scanner = new Scanner(System.in);
		boolean gaming = true;
		boolean changePlayer=true;
		while (gaming) {


			String[] command = CommandReader.readCommand(scanner);

			if (command[0].equalsIgnoreCase("move")){
				try {
					//TODO controllare comando
					String message = "";
					String[] commandValidated=this.validateMoveCommand(command);
					playerTurn= this.retrievePlayer(commandValidated,playerTurn, changePlayer);
					changePlayer=false;

					int diceValue=this.retrieveDiceValue(commandValidated);
					message = message.concat(playerTurn.getNickname()+" rolls "+commandValidated[2]+". ");

					Cell currentPlayerCell= playerTurn.getCell();
					if (currentPlayerCell.canPlayerMove()){
						message = message.concat(playerTurn.getNickname()+" moves from "+currentPlayerCell.getIndexCell()
						+" to "+this.destination(diceValue, currentPlayerCell)+". ");

						int index=this.calculateIndextDestinationCell(diceValue, currentPlayerCell.getIndexCell());

						Cell destinationCell=this.getNextCell(index);
						if(destinationCell.isBusy()){
							message=message.concat("On "+this.writeCell(destinationCell)
							+" there is " + destinationCell.getPlayer().getNickname()+",  who returns to "+currentPlayerCell.getLabel());

							currentPlayerCell.setPlayer(destinationCell.getPlayer());
							this.getPlayerFromList(destinationCell.getPlayer()).setCell(currentPlayerCell);
						}else{
							currentPlayerCell.removePlayer(playerTurn);
						}

						int nexIndex=destinationCell.action( diceValue);

						if (destinationCell instanceof GooseCell){
							do {
								message =message.concat(playerTurn.getNickname()+ " moves again and goes to "+nexIndex+". ");
								destinationCell=this.gameboard.getCellByIndex(nexIndex);
								nexIndex=destinationCell.action( diceValue);

							} while (destinationCell.getIndexCell()!=nexIndex);
						}
						destinationCell=this.getNextCell(nexIndex);
						destinationCell.inboundPlayer(playerTurn);
						playerTurn.setCell(destinationCell);


						if(destinationCell.getIndexCell()==(this.gameboard.getTotCellNumber()-1)){
							message = message.concat(playerTurn.getNickname()+ " Wins!!");

							gaming= false;
						}
						else if ((diceValue+currentPlayerCell.getIndexCell()) >this.gameboard.getTotCellNumber()){
							message = message.concat(playerTurn.getNickname() + " bounces! "+playerTurn.getNickname()+" returns to "
									+(this.gameboard.getTotCellNumber() - (diceValue - (this.gameboard.getTotCellNumber() - currentPlayerCell.getIndexCell()))));

						}
						else if(destinationCell.getIndexCell()==12){
							message = message.concat(playerTurn.getNickname()+" jumps to 12");

						}
						System.out.println(message);
						changePlayer=true;

					}else{
						System.out.println(playerTurn.getNickname() + " skip turn");
					}
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}

			}else if(command[0].equalsIgnoreCase("leave")){

				gaming = false;
			}else{
				System.out.println("Invalid command");
			}

		}
		System.out.println("End Game");
		scanner.close();
		return false;
	}



	private String destination(int diceValue, Cell currentPlayerCell) throws GameBoardException {
		return ((currentPlayerCell.getIndexCell()+diceValue)>63?Integer.valueOf(this.gameboard.getTotCellNumber()-1).toString():this.gameboard.getCellByIndex(currentPlayerCell.getIndexCell()+diceValue).getLabel());
	}

	private Player getPlayerFromList(Player player) {
		for (Player p : this.playerList) {
			if (p.getNickname().equalsIgnoreCase(player.getNickname())){
				return p;
			}
		}
		return null;

	}



	private int calculateIndextDestinationCell(int diceValue, int currentIndex) {
		if((diceValue+currentIndex)<(this.gameboard.getTotCellNumber()+1)){
			return diceValue+currentIndex;
		}else{
			return this.gameboard.getTotCellNumber() - (diceValue - (this.gameboard.getTotCellNumber() - currentIndex));
		}
	}


	private String[] validateMoveCommand(String[] command) throws MoveCommandExceptionException {
		String[] commandTmp ;
		if (command.length==2){
			commandTmp= new String[3];
			for (int i = 0; i < command.length; i++) {
				commandTmp[i]=command[i];
			}
			commandTmp[command.length]=Dice.throwDice()+","+Dice.throwDice();
		}else{
			commandTmp=command;
		}

		if(!this.playerExists(commandTmp[1])){
			throw new MoveCommandExceptionException("Invalid command, player missing");
		}

		return commandTmp;
	}


	private String writeCell(Cell cell) {
		return cell.getLabel();
	}




	private Cell getNextCell(int i) throws GameBoardException {
		return this.gameboard.getCellByIndex(i);
	}



	private int retrieveDiceValue(String[] command) throws MoveCommandExceptionException,DiceException {
		String[] diceValue= command[2].split(",");

		int tot=0;
		try {
			for (int i = 0; i < diceValue.length; i++) {
				int dice=Integer.valueOf(diceValue[i]);
				if ((dice>0) && (dice <7)){
					tot+= Integer.valueOf(diceValue[i]);
				}else{
					throw new DiceException("Value of "+(i+1)+ "� dice is invalid, it must be between 1 and 6");
				}
			}
		} catch (NumberFormatException e) {
			throw new MoveCommandExceptionException("The command param '"+command[2]+"' is invalid");
		}
		return tot;
	}



	private Player retrievePlayer(String[] command, Player previousPlayer, boolean changePlayer) throws MoveCommandExceptionException {
		String nickname= command[1];

		if (changePlayer){
			for (Player player : this.playerList) {
				if (player.getNickname().equalsIgnoreCase(nickname) ){
					if ((previousPlayer==null) || !previousPlayer.getNickname().equalsIgnoreCase(player.getNickname())){
						return player;
					}
					else{
						throw new MoveCommandExceptionException("Change player, '"+previousPlayer.getNickname() +
								"' just played.");
					}

				}
			}
			throw new MoveCommandExceptionException("Player, "+previousPlayer.getNickname() +
					" out of game");

		}else{
			return previousPlayer;
		}
	}

	private void addUserToStartCell() throws GameBoardException {
		Cell startCell=this.gameboard.getCellByIndex(0);

		for (Player player : this.playerList) {
			startCell.setPlayer(player);
			player.setCell(startCell);
		}
	}





	private boolean playerExists(String nickanme) {
		for (Player player : this.playerList) {
			if(player.getNickname().equalsIgnoreCase(nickanme)){
				return true;
			}
		}
		return false;
	}



	private void init(){
		System.out.println("Start init board");
		this.gameboard= GameBoard.builder().initBoard();
		System.out.println("End init board");
	}


}
