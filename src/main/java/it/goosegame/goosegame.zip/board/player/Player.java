/**
 * @author fabrizio.caloni
 */
package it.goosegame.board.player;

import it.goosegame.board.cell.Cell;
import it.goosegame.board.exception.PlayerBuilderException;

public class Player {
	private String nickname;
	private int id;
	private Cell cell;



	public Player(int id,String nickname ) {
		super();
		this.nickname = nickname;
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public static Player.Builder builder() {
		return new Player.Builder();
	}
	


	public Cell getCell() {
		return cell;
	}

	public void setCell(Cell cell) {
		this.cell = cell;
	}

	@Override
	public String toString() {
		return nickname ;
	}


	public static final class Builder {
		private String nickname;
		private int id;
		private Builder(){
		}

		public Player build() throws PlayerBuilderException {
			if (nickname== null || nickname.trim().equals("")){
				throw new PlayerBuilderException("Nickname must not null or empty");
			}
			return new Player(id, nickname);
		}

		public Builder nickname(String nickname){
			this.nickname=nickname;
			return this;
		}

		public Builder id(int id){
			this.id=id;
			return this;
		}
	}


}
