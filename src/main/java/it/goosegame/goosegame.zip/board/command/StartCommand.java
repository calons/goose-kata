package it.goosegame.board.command;

import java.util.List;

import it.goosegame.board.GameBoard;
import it.goosegame.board.cell.Cell;
import it.goosegame.board.exception.CommandException;
import it.goosegame.board.exception.GameBoardException;
import it.goosegame.board.player.Player;

public class StartCommand implements Command{

	@Override
	public void run(String[] command, GameBoard gameBoard, List<Player> playerList) throws CommandException {
		if (playerList.size()!=2){
			System.out.println("Players must be two! Please insert the player");
			break;
		}
		try {
			this.addUserToStartCell();
			execution = this.runGame();

		} catch (GameBoardException e) {
			System.out.println(e.getMessage());
		}		
	}

	private GameBoard addUserToStartCell(GameBoard gameBoard, List<Player> playerList) throws GameBoardException {
		GameBoard gameBoardTmp =  gameBoard;
		Cell startCell=gameBoard.getCellByIndex(0);

		for (Player player : playerList) {
			startCell.setPlayer(player);
			player.setCell(startCell);
		}
		return gameBoardTmp;
	}


}
