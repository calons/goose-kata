package it.goosegame.board.command;

import java.util.List;

import it.goosegame.board.GameBoard;
import it.goosegame.board.exception.CommandException;
import it.goosegame.board.player.Player;

public class AddCommand implements Command{

	@Override
	public void run(String[] command,GameBoard gameBoard, List<Player> playerList) throws CommandException {

		try {
			if(!this.validateAddCommand(command)){
				System.out.println("Command doesn't not valid");
				return;
			}

			Player player = Player.builder().nickname(command[2]).id(playerList.size()+1).build();
			if(this.playerExists(playerList,player.getNickname())){
				System.out.println(player.getNickname()+": already existing player");
				return;
			}
			if (playerList.size()>=2){
				System.out.println("Allows only two players");
			}else{
				playerList.add(player);
				System.out.println("players: "+playerList.toString());
			}
		} catch (Exception e) {
			throw new CommandException(e.getMessage());
		}

	}

	private boolean playerExists( List<Player> playerList,String nickanme) {
		for (Player player : playerList) {
			if(player.getNickname().equalsIgnoreCase(nickanme)){
				return true;
			}
		}
		return false;
	}

	private boolean validateAddCommand(String[] command) {
		return (command.length==3) && command[1].equalsIgnoreCase("player")&& !command[2].equals("");
	}

}
