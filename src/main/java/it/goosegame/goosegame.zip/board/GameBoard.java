package it.goosegame.board;

import it.goosegame.board.cell.BaseCell;
import it.goosegame.board.cell.BridgeCell;
import it.goosegame.board.cell.Cell;
import it.goosegame.board.cell.GooseCell;
import it.goosegame.board.cell.StartCell;
import it.goosegame.board.exception.GameBoardException;

public class GameBoard {

	private int totCellNumber=64;
	private Cell[] cellBoardList = new Cell[64];


	public GameBoard(Cell[] cellBoardList) {
		super();
		this.cellBoardList = cellBoardList;
	}

	public Cell getCellByIndex(int index) throws GameBoardException{

		if (index>totCellNumber){
			throw new GameBoardException("The index "+index+" out of range");
		}
		return cellBoardList[index];

	}

	public int getTotCellNumber() {
		return totCellNumber;
	}



	public void setTotCellNumber(int totCellNumber) {
		this.totCellNumber = totCellNumber;
	}



	public static GameBoard.Builder builder() {
		return new GameBoard.Builder();
	}

	public static final class Builder {
		private Cell[] cellBoardListTmp=new Cell[64]; ;
		private Builder(){
		}

		public GameBoard initBoard()  {

			for (int i = 0; i < 64; i++) {
				if(i==0){
					cellBoardListTmp[i]=new StartCell();
				}else if(i==6){
					cellBoardListTmp[i]= new BridgeCell(i);
				}else if (i==5 || i==9 || i==14 ||i==18 ||i==23 ||i==27){
					cellBoardListTmp[i]=new GooseCell(i);
				}else{
					cellBoardListTmp[i]=new BaseCell(i);
				}
			}
			return new GameBoard(cellBoardListTmp);
		}

	}

}
