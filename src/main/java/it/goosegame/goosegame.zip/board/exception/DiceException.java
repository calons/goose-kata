/**
 * @author fabrizio.caloni
 */
package it.goosegame.board.exception;

public class DiceException extends Exception {

	private static final long serialVersionUID = 1L;

	public DiceException(String message) {
		super(message);	
	}

}
